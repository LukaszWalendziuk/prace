function red() {
    var procenty=document.getElementById('procenty').value;
    var kroj=document.getElementById('kroj').value;                      
    if  (kroj==='kursywa') document.getElementById('wynik').style = "color: red; font-style: italic; font-size: "+procenty+"%;";
    else document.getElementById('wynik').style="color: red;font size: "+procenty+"%;";
   }
   function green() {
    var procenty=document.getElementById('procenty').value;
    var kroj=document.getElementById('kroj').value;                      
    if  (kroj==='kursywa') document.getElementById('wynik').style = "color: green; font-style: italic; font-size: "+procenty+"%;";
    else document.getElementById('wynik').style="color: green;font size: "+procenty+"%;";
   }
   function blue() {
    var procenty=document.getElementById('procenty').value;
    var kroj=document.getElementById('kroj').value;                      
    if  (kroj==='kursywa') document.getElementById('wynik').style = "color: blue; font-style: italic; font-size: "+procenty+"%;";
    else document.getElementById('wynik').style="color: blue;font size: "+procenty+"%;";
   }
   
   function dodaj(){
    var liczba1=document.getElementById('liczba1').value;
    var liczba2=document.getElementById('liczba2').value;
    let suma=Number(liczba1) + Number(liczba2);
    document.getElementById('suma').innerHTML=suma;
   }